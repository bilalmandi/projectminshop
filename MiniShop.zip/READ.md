# MiniShop

## Overview
MiniShop is a simplified e-commerce platform allowing users to browse products, add items to a shopping cart, and place orders.

## Features
- User registration and login.
- Product browsing and details view.
- Cart functionality with add/remove items.
- Order placement and history view.

## Tech Stack
- **Frontend**: React, Axios
- **Backend**: Node.js, Express
- **Database**: MongoDB (Atlas) //