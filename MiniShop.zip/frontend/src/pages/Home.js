import { useEffect, useState } from 'react';
import { fetchProducts } from '../api/api';
import Product from '../components/Product';

const Home = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const loadProducts = async () => {
      const response = await fetchProducts();
      setProducts(response.data);
    };
    loadProducts();
  }, []);

  return (
    <div>
      <h1 className="title">Products</h1>
      <div className="products-container">
        {products.map((product) => (
          <Product key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default Home;
