const Profile = () => (
    <div>
      <h1>User Profile</h1>
      <p>Name: Sample User</p>
      <p>Email: user@example.com</p>
    </div>
  );
  
  export default Profile;
  