
export const mockProducts = [
    { id: 1, name: 'Product 1', description: 'Description of Product 1', price: '$9.99' },
    { id: 2, name: 'Product 2', description: 'Description of Product 2', price: '$12.99' },
    { id: 3, name: 'Product 3', description: 'Description of Product 3', price: '$33.98' },
    { id: 4, name: 'Product 4', description: 'Description of Product 4', price: '$59.99' },
    { id: 4, name: 'Product 5', description: 'Description of Product 5', price: '$112.97' },
      {
        id: 1,
        name: "Wireless Mouse",
        description: "A sleek wireless mouse with ergonomic design.",
        price: 19.99,
        stock: 120,
        imageUrl: "https://via.placeholder.com/150"
      },
      {
        id: 2,
        name: "Gaming Keyboard",
        description: "Mechanical keyboard with RGB lighting.",
        price: 59.99,
        stock: 60,
        imageUrl: "https://via.placeholder.com/150"
      },
      
    ];
    
  