import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:5000/api' });

export const fetchProducts = () => API.get('/products');

export const fetchProductById = (id) => API.get(`/products/${id}`);

export const registerUser = (userData) => API.post('/users/register', userData);

export const loginUser = (userData) => API.post('/users/login', userData);

export const createOrder = (orderData) => API.post('/orders', orderData);

export const fetchOrdersByUser = (userId) => API.get(`/orders/${userId}`);
