import { Link } from 'react-router-dom';

const Product = ({ product }) => (
  <div className="product-card">
    <h3 className="product-title">{product.name}</h3>
    <p className="product-price">{product.price}</p>
    <Link to={`/product/${product.id}`} className="product-link">
      View Details
    </Link>
  </div>
);

export default Product;
